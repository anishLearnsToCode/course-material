import numpy as np


# Colors
COLOR_1 = np.array([255, 255, 255])
COLOR_2 = np.array([229, 232, 232])
COLOR_3 = np.array([204, 209, 209])
COLOR_4 = np.array([178, 186, 187])
COLOR_5 = np.array([153, 163, 164])
COLOR_6 = np.array([127, 140, 141])
COLOR_7 = np.array([97, 106, 107])
COLOR_8 = np.array([81, 90, 90])
COLOR_9 = np.array([66, 73, 73])
COLOR_BLUE = np.array([255, 0, 0])
COLOR_BLACK = np.array([0, 0, 0])

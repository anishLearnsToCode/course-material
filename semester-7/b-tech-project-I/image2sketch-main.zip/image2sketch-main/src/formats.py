# Formats
JPG = '.jpg'
JPEG = '.jpeg'
PNG = '.png'

# decides weight of 3d lattice in the linear combination of images
HAND_DRAWN = 0

# odd variable that decides the window size for gaussian blurring and convolution
SKETCH_DENSITY = 27

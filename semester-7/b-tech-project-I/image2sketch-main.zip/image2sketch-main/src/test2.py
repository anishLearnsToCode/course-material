import matplotlib.pyplot as plt
import cv2

I = cv2.imread('../data/lenna.png')
imgplot = plt.imshow(I)
